import os
from tkinter import Y
from turtle import heading
from urllib.request import Request
from flask import request
from flask import Blueprint, Flask, render_template, request, flash, jsonify, redirect, url_for, Response
from flask_login import login_required, current_user
from .models import Student, Attendance
from . import db
import json
import cv2
from deepface import DeepFace
import pandas as pd
from mtcnn import MTCNN
import matplotlib.pyplot as plt
import time
import csv


views = Blueprint('views', __name__)
camera=cv2.VideoCapture(1)


def generate_frames():
    while True:
            
        ## read the camera frame
        success,frame=camera.read()
        #if button 
        #flask aps schulder
        if not success:
            break

        else:
            ret,buffer=cv2.imencode('.jpg',frame)
            frame=buffer.tobytes()

        yield(b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')



@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    data = Attendance.query.all()
    headings = ['First Name', 'Last Name','Student ID', 'Image', 'Attendance', 'Time']

    modules = ['Data Mining','Big Data', 'Web Programming', 'Interaction Design', 'Image Processing', 'Neural Networks And Deep Learning']

    return render_template("home.html", user=current_user, data=data, headings=headings, modules=modules)



@views.route('/video')
def video():
    return Response(generate_frames(),mimetype='multipart/x-mixed-replace; boundary=frame')



@views.route('/capture_image', methods = ['GET', 'POST'])
def capture():
    _, frame = camera.read()
    img_name = "current_image.jpg"
    cv2.imwrite(img_name, frame)
    student_id = recognition()

    if student_id != 0:
        attendance(student_id)

    data = Attendance.query.all()
    headings = ['First Name', 'Last Name','Student ID', 'Image', 'Attendance', 'Time']

    return render_template("home.html", user=current_user, data=data, headings=headings)



def save_crop_image(image,student_id):
    image = "images\\" + image
    img = cv2.cvtColor(cv2.imread(image), cv2.COLOR_BGR2RGB) 
    
    filename = student_id+".jpg"

    crop_img = create_box(img)

    path = "cropped_images\\"
    cv2.imwrite(os.path.join(path, filename), crop_img)




def recognition():
    img = cv2.cvtColor(cv2.imread("current_image.jpg"), cv2.COLOR_BGR2RGB) 

    face_image = create_box(img)
    face_img_name = "current_face_image.jpg"
    cv2.imwrite(face_img_name,face_image)

    directory = 'cropped_images\\'
    model_name = 'ArcFace'
    threshold = 0.69
    
    potential_matches = {}

    for filename in os.listdir(directory):
        image_path =directory + filename

        resp = DeepFace.verify(face_image, image_path, model_name, enforce_detection=False)
        distance = resp.get('distance')
        print(distance)

        if distance < threshold:
            potential_matches[filename] = distance
          
        
    print(potential_matches)
    match = min(potential_matches,key=potential_matches.get, default="")
    
    if len(match) == 0:
        flash('Face does not match anyone in the database', category='error')
        student_id = 0

    else: 
        student_id = match.split(".jpg")
        student_id = student_id[0]
    
    return student_id



def create_box(image):
    detector = MTCNN()
    #image = cv2.cvtColor(cv2.imread(image), cv2.COLOR_BGR2RGB)
    face = detector.detect_faces(image)

    bounding_box = face[0]['box']
    keypoints = face[0]['keypoints']

    # # x = 0
    # # y = 1
    # # w = 2
    # # h = 3

    cv2.rectangle(image,
                (bounding_box[0], bounding_box[1]),
                (bounding_box[0]+bounding_box[2],bounding_box[1]+bounding_box[3]),
                (0,155,255),
                2)
    
    cv2.circle(image, (keypoints['left_eye']), 2, (0,155,255), 2)
    cv2.circle(image, (keypoints['right_eye']), 2, (0,155,255), 2)
    cv2.circle(image, (keypoints['nose']), 2, (0,155,255), 2)
    cv2.circle(image, (keypoints['mouth_left']), 2, (0,155,255), 2)
    cv2.circle(image, (keypoints['mouth_right']), 2, (0,155,255), 2)

    image = image[bounding_box[1]:bounding_box[1]+bounding_box[3], bounding_box[0]:bounding_box[0]+bounding_box[2]]
   
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return image



@views.route('/student', methods=['GET', 'POST'])
def add_student():
    data = Student.query.all()
    headings = ['First Name', 'Last Name','Student ID', 'Image', 'Delete']
    if request.method == 'POST':
        first_name = request.form.get('firstName')
        last_name = request.form.get('lastName')
        student_id = request.form.get('studentId')
        image = request.form.get('img')

        student = Student.query.filter_by(student_id=student_id).first()
        if student:
            flash('Student already exists.', category='error')
        elif len(student_id) != 9:
            flash('Student ID must be 9 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        
        else:
            new_student = Student(first_name=first_name, last_name=last_name, student_id=student_id, image=image)
            db.session.add(new_student)
            db.session.commit()
            save_crop_image(image,student_id)
            flash('Student added!', category='success')
            return redirect(url_for('views.add_student'))

    return render_template("student.html", user=current_user, data=data, headings=headings)



@views.route('/delete/<int:id>', methods=['GET'])
def delete_student(id):
    student_to_delete = Student.query.get_or_404(id)
    student_id = student_to_delete.student_id
 
    directory = 'cropped_images\\'
    filename = str(student_id) + ".jpg"
    image_path = directory + filename
    print(image_path)

    try:
        db.session.delete(student_to_delete)
        db.session.commit()
        os.remove(image_path)
        flash("Student deleted!", category='success')

        return redirect(url_for('views.add_student'))

    except:
        flash("There was a problem deleting this Student, try again", category='error')
        return redirect(url_for('views.add_student'))



@views.route('/attendance', methods=['GET', 'POST'])
def attendance(student_id):
    student_to_attend = Student.query.filter_by(student_id=student_id).first()
    current_time = time.strftime('%H:%M')

    attendance = Attendance.query.filter_by(student_id=student_id).first()
    if attendance:
            flash('Your attendance has already been recorded', category='error')
    
    else:
        first_name = student_to_attend.first_name
        last_name = student_to_attend.last_name
        student_id = student_id
        image = student_to_attend.image
        attendance = True
        date_time = current_time

        attend_student = Attendance(first_name=first_name, last_name=last_name, student_id=student_id, image=image, attendance=attendance, date_time=date_time)
        db.session.add(attend_student)
        db.session.commit()
        flash('Your attendance has been successfully recorded!', category='success')

    return redirect(url_for('views.home'))



@views.route('/module', methods = ['POST', 'GET'])
def module():
    m = request.get_json()
    module = json.loads(m)
    
    global selected_module
    selected_module = module.get('module')

    return redirect(url_for('views.home'))
    



@views.route('/export_csv', methods = ['GET', 'POST'])
def export():
    print("exporting...")

    date = time.strftime('%d-%m-%Y')
    date= str(date)
    filename = selected_module + "_" + date
    print(filename)

    path = "attendances//" + filename

    attendance_to_export = Attendance.query.all()

    file = open(path, 'w',newline='')

    writer = csv.writer(file)

    header = ['First Name', 'Last Name', 'Student ID', 'Image', 'Attedance', 'Time']
    writer.writerow(header)

    for x in attendance_to_export:
        first_name = x.first_name
        last_name = x.last_name
        student_id = x.student_id
        image = x.image
        attendance = x.attendance
        date_time = x.date_time

        data = [first_name, last_name, student_id, image, attendance, date_time]

        writer.writerow(data)
    
    file.close()

    flash('Attendance table has been succesfully exported!', category='success')
    
    return redirect(url_for('views.home'))



@views.route('/clear_table')
def clear():
    attendance_to_clear = Attendance.query.all()
    for x in attendance_to_clear:
        db.session.delete(x)
    db.session.commit()

    return redirect(url_for('views.home'))
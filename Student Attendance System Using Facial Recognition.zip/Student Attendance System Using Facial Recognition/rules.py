def findDecision(obj): #obj[0]: Distance
	# {"feature": "Distance", "instances": 1000, "metric_value": 0.9958, "depth": 1}
	if obj[0]>0.6894757987856867:
		return 'Non Match'
	elif obj[0]<=0.6894757987856867:
		return 'Match'
	else: return 'Match'
